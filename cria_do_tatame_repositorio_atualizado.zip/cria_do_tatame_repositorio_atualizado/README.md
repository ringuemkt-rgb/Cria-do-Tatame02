# Cria do Tatame — Repositório Atualizado

Jogo web offline em **HTML, CSS e JavaScript**, pronto para versionamento, publicação no GitHub e empacotamento futuro para Android.

## Estado atual do projeto

Esta build já entrega:

- campanha com **24 missões**
- **8 capítulos**
- treino, energia, XP, moedas e nível
- talentos e conquistas
- loja e progressão de build
- combate por turnos
- finais múltiplos
- modo livre após zerar
- salvamento local
- funcionamento offline via service worker

## Estrutura

```text
index.html
styles.css
app.js
manifest.json
sw.js
README.md
CHANGELOG.md
LICENSE.txt
.gitignore
```

## Como rodar

### Opção 1 — abrir direto
Abra `index.html` no navegador.

### Opção 2 — servidor local
Use um servidor simples para testar como PWA:

```bash
python -m http.server 8080
```

Depois abra:

```text
http://localhost:8080
```

## Como publicar no GitHub

```bash
git init
git add .
git commit -m "feat: repositorio atualizado do Cria do Tatame"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/cria-do-tatame.git
git push -u origin main
```

## Próximos passos recomendados

1. Trocar arte provisória por arte autoral.
2. Adicionar áudio e efeitos.
3. Balancear economia e dificuldade.
4. Portar para Android com Capacitor, Cordova ou TWA.

## Observação honesta

Este projeto está **completo como jogo web offline casual/progressivo**.
Ele **não é um AAA nativo Android** e ainda precisa de mais arte, áudio, animação e polimento para mercado premium.
