# Changelog

## 2026-03-24
- Repositório consolidado do jogo web "Cria do Tatame"
- Campanha completa com 24 missões e 8 capítulos
- Sistemas de treino, loja, talentos, conquistas, finais múltiplos e modo livre
- PWA offline com manifest e service worker
- Estrutura pronta para versionamento e publicação no GitHub
