const STORAGE_KEY = "criaDoTatameSave_v2";

const chapters = [
  { id: 1, name: "Asfalto e Tatame", description: "Começo humilde, primeira disciplina.", missionIds: [1,2,3] },
  { id: 2, name: "Respeito se Conquista", description: "Desafios maiores e mais técnica.", missionIds: [4,5,6] },
  { id: 3, name: "Noite de Luta", description: "Torneios duros, mente e gás testados.", missionIds: [7,8,9] },
  { id: 4, name: "O Nome no Mapa", description: "A base ficou forte; agora vem a cobrança pesada.", missionIds: [10,11,12] },
  { id: 5, name: "Pressão de Verdade", description: "Patamar acima, ritmo cruel e margem zero para erro.", missionIds: [13,14,15] },
  { id: 6, name: "Circuito dos Cascudos", description: "Veteranos, casca grossa e guerra mental.", missionIds: [16,17,18] },
  { id: 7, name: "Nacional de Elite", description: "Agora só sobra gente pronta.", missionIds: [19,20,21] },
  { id: 8, name: "Lenda do Tatame", description: "Último degrau: legado, honra e título.", missionIds: [22,23,24] }
];

const missionsMaster = [
  { id: 1, chapter: 1, name: "Primeiro Sparring", type: "sparring", energyCost: 1, recommended: 18, rewardCoins: 40, rewardXp: 40, opponent: { name: "Nego Rápido", style: "Boxe de rua", hp: 78, strength: 9, technique: 8, cardio: 7, focus: 6, honor: 6 }, story: "Seu primeiro teste. Golpes limpos, cabeça fria.", unlocks: [] },
  { id: 2, chapter: 1, name: "Rolê no Tatame", type: "grappling", energyCost: 1, recommended: 23, rewardCoins: 55, rewardXp: 45, opponent: { name: "Junin Queda", style: "Queda e pressão", hp: 88, strength: 10, technique: 9, cardio: 7, focus: 7, honor: 7 }, story: "Aprenda a cair, levantar e controlar.", unlocks: [] },
  { id: 3, chapter: 1, name: "Desafio da Quadra", type: "boss", energyCost: 2, recommended: 30, rewardCoins: 90, rewardXp: 70, opponent: { name: "Breno Cascudo", style: "Casca grossa", hp: 108, strength: 12, technique: 10, cardio: 9, focus: 8, honor: 7 }, story: "Quem manda é a disciplina. Sem pose, só trabalho.", unlocks: ["talent_tempo"] },
  { id: 4, chapter: 2, name: "Circuito da Comunidade", type: "sparring", energyCost: 1, recommended: 36, rewardCoins: 80, rewardXp: 65, opponent: { name: "Japa Giro", style: "Chute veloz", hp: 100, strength: 11, technique: 13, cardio: 11, focus: 9, honor: 7 }, story: "Luta limpa, torcida pesada, postura firme.", unlocks: [] },
  { id: 5, chapter: 2, name: "Copa do Projeto", type: "grappling", energyCost: 2, recommended: 42, rewardCoins: 100, rewardXp: 75, opponent: { name: "Mika Trava", style: "Clinch e controle", hp: 112, strength: 13, technique: 13, cardio: 11, focus: 10, honor: 8 }, story: "Controle o espaço e não se entregue ao caos.", unlocks: [] },
  { id: 6, chapter: 2, name: "Professor na Arquibancada", type: "boss", energyCost: 2, recommended: 50, rewardCoins: 140, rewardXp: 100, opponent: { name: "Cadu Firmeza", style: "Técnica pura", hp: 126, strength: 14, technique: 16, cardio: 12, focus: 12, honor: 10 }, story: "Agora o jogo ficou sério. Mostre respeito e constância.", unlocks: ["talent_guardiao"] },
  { id: 7, chapter: 3, name: "Seletiva Regional", type: "sparring", energyCost: 2, recommended: 58, rewardCoins: 150, rewardXp: 110, opponent: { name: "Rato de Academia", style: "Volume e ritmo", hp: 134, strength: 15, technique: 16, cardio: 15, focus: 12, honor: 10 }, story: "Fôlego e postura, senão a luta escapa.", unlocks: [] },
  { id: 8, chapter: 3, name: "Guerra de Três Rounds", type: "arena", energyCost: 2, recommended: 66, rewardCoins: 170, rewardXp: 125, opponent: { name: "Pardal Míssil", style: "Explosão e pressão", hp: 146, strength: 18, technique: 15, cardio: 16, focus: 13, honor: 9 }, story: "Não é briga: é controle, inteligência e coração.", unlocks: [] },
  { id: 9, chapter: 3, name: "Main Event da Vila", type: "boss", energyCost: 3, recommended: 75, rewardCoins: 220, rewardXp: 160, opponent: { name: "Léo Martelo", style: "Potência brutal", hp: 160, strength: 21, technique: 16, cardio: 17, focus: 14, honor: 11 }, story: "Um nome de peso. Caiu, levanta. Venceu, agradece.", unlocks: ["talent_ferro"] },
  { id: 10, chapter: 4, name: "Olheiros Presentes", type: "sparring", energyCost: 2, recommended: 82, rewardCoins: 230, rewardXp: 170, opponent: { name: "Cris Cobra", style: "Contra-ataque venenoso", hp: 170, strength: 19, technique: 20, cardio: 18, focus: 16, honor: 12 }, story: "Chegou a hora de ser visto sem perder sua essência.", unlocks: [] },
  { id: 11, chapter: 4, name: "Final Nacional", type: "arena", energyCost: 3, recommended: 90, rewardCoins: 260, rewardXp: 190, opponent: { name: "Mestre Fantasma", style: "Experiência fria", hp: 186, strength: 21, technique: 22, cardio: 19, focus: 18, honor: 13 }, story: "Respire. Técnica vence nervosismo.", unlocks: [] },
  { id: 12, chapter: 4, name: "Cria do Tatame", type: "boss", energyCost: 3, recommended: 100, rewardCoins: 320, rewardXp: 220, opponent: { name: "Titã do Tatame", style: "Completo e implacável", hp: 210, strength: 24, technique: 24, cardio: 22, focus: 20, honor: 14 }, story: "Você venceu o circuito base. Agora o jogo abre de verdade.", unlocks: ["talent_sangue_frio"] },
  { id: 13, chapter: 5, name: "Noite dos Veteranos", type: "sparring", energyCost: 2, recommended: 108, rewardCoins: 340, rewardXp: 235, opponent: { name: "Boca Seca", style: "Ritmo malandro", hp: 220, strength: 24, technique: 25, cardio: 23, focus: 21, honor: 14 }, story: "Aqui não vence quem acelera sem pensar.", unlocks: [] },
  { id: 14, chapter: 5, name: "Queda ou Queda", type: "grappling", energyCost: 3, recommended: 116, rewardCoins: 360, rewardXp: 250, opponent: { name: "Touro Baixo", style: "Pressão de tronco", hp: 232, strength: 27, technique: 24, cardio: 23, focus: 20, honor: 15 }, story: "Centro de gravidade, tempo e quadril. Sem isso, abraço do urso.", unlocks: [] },
  { id: 15, chapter: 5, name: "Cinturão de Aço", type: "boss", energyCost: 3, recommended: 124, rewardCoins: 390, rewardXp: 270, opponent: { name: "Moisés Muralha", style: "Defesa de pedra", hp: 246, strength: 28, technique: 26, cardio: 24, focus: 23, honor: 17 }, story: "Paciência de caçador. Um erro e ele congela a luta.", unlocks: ["talent_cascadura"] },
  { id: 16, chapter: 6, name: "Regional dos Brabos", type: "sparring", energyCost: 3, recommended: 132, rewardCoins: 420, rewardXp: 290, opponent: { name: "Norte Quente", style: "Agressão limpa", hp: 258, strength: 29, technique: 27, cardio: 26, focus: 23, honor: 17 }, story: "Cabeça no gelo, mão sem medo.", unlocks: [] },
  { id: 17, chapter: 6, name: "Jaula de Respeito", type: "arena", energyCost: 3, recommended: 140, rewardCoins: 450, rewardXp: 310, opponent: { name: "Galego Torque", style: "Explosão clínica", hp: 272, strength: 31, technique: 28, cardio: 27, focus: 24, honor: 18 }, story: "Vai doer, então pense bonito e lute feio.", unlocks: [] },
  { id: 18, chapter: 6, name: "Professor sem Sorriso", type: "boss", energyCost: 4, recommended: 148, rewardCoins: 490, rewardXp: 340, opponent: { name: "Sensei Vazio", style: "Leitura de tempo", hp: 286, strength: 31, technique: 32, cardio: 28, focus: 27, honor: 20 }, story: "Ele lê padrão. Se repetir, perde.", unlocks: ["talent_lobo"] },
  { id: 19, chapter: 7, name: "Mata-Mata Nacional", type: "sparring", energyCost: 3, recommended: 156, rewardCoins: 520, rewardXp: 360, opponent: { name: "Paulista Seco", style: "Técnica reta", hp: 300, strength: 32, technique: 33, cardio: 29, focus: 28, honor: 20 }, story: "Sem emoção demais. O detalhe decide.", unlocks: [] },
  { id: 20, chapter: 7, name: "Semifinal Sangrada", type: "arena", energyCost: 4, recommended: 165, rewardCoins: 560, rewardXp: 390, opponent: { name: "Mina Tempestade", style: "Pressão móvel", hp: 318, strength: 34, technique: 34, cardio: 31, focus: 29, honor: 21 }, story: "Jogo grande pede frieza e pulmão.", unlocks: [] },
  { id: 21, chapter: 7, name: "Rei do Ranking", type: "boss", energyCost: 4, recommended: 174, rewardCoins: 610, rewardXp: 430, opponent: { name: "Arthur Cintura", style: "Jogo completo", hp: 336, strength: 35, technique: 36, cardio: 32, focus: 31, honor: 22 }, story: "O cara que todo mundo mira. Agora ele olha pra você.", unlocks: ["talent_campeao"] },
  { id: 22, chapter: 8, name: "Teatro dos Campeões", type: "sparring", energyCost: 4, recommended: 183, rewardCoins: 660, rewardXp: 470, opponent: { name: "Muralha Negra", style: "Volume e escudo", hp: 352, strength: 37, technique: 36, cardio: 34, focus: 32, honor: 23 }, story: "Agora qualquer vacilo vira manchete.", unlocks: [] },
  { id: 23, chapter: 8, name: "Coroa de Espinhos", type: "arena", energyCost: 4, recommended: 192, rewardCoins: 720, rewardXp: 510, opponent: { name: "Lince Real", style: "Contra-ataque cirúrgico", hp: 370, strength: 38, technique: 39, cardio: 35, focus: 34, honor: 24 }, story: "Título não é glamour. É cobrança.", unlocks: [] },
  { id: 24, chapter: 8, name: "Lenda do Tatame", type: "finalboss", energyCost: 5, recommended: 205, rewardCoins: 1000, rewardXp: 800, opponent: { name: "Imperador do Tatame", style: "Completo, frio e cruel", hp: 410, strength: 41, technique: 41, cardio: 38, focus: 37, honor: 26 }, story: "A última porta. Aqui acaba o amadorismo e começa o legado.", unlocks: ["ending"] }
];

const trainings = [
  { id: "forca", name: "Treino de Força", effect: { strength: 2, xp: 12 }, energyCost: 1, flavor: "Saco, barra, base e explosão." },
  { id: "tecnica", name: "Drill de Técnica", effect: { technique: 2, xp: 12 }, energyCost: 1, flavor: "Repetição limpa até virar reflexo." },
  { id: "cardio", name: "Condicionamento", effect: { cardio: 2, xp: 12 }, energyCost: 1, flavor: "Pulmão queimando, mente firme." },
  { id: "foco", name: "Respiração e Foco", effect: { focus: 2, honor: 1, xp: 10 }, energyCost: 1, flavor: "Menos ruído, mais presença." },
  { id: "honra", name: "Serviço no Dojo", effect: { honor: 2, focus: 1, xp: 10 }, energyCost: 1, flavor: "Disciplina também se treina fora da luta." },
  { id: "descanso", name: "Dormir e Recuperar", effect: { energy: 6, hpRecovery: true }, energyCost: 0, flavor: "Descanso também é treino de campeão." }
];

const shopItems = [
  { id: "luva", name: "Luva Surrada de Guerra", cost: 120, effect: { strength: 3 }, desc: "Mais potência nos golpes." },
  { id: "bandagem", name: "Bandagem Firme", cost: 110, effect: { focus: 2, technique: 1 }, desc: "Pulso estável, mente alinhada." },
  { id: "caneleira", name: "Caneleira de Treino", cost: 140, effect: { cardio: 3 }, desc: "Peso nas pernas, leveza na hora certa." },
  { id: "rashguard", name: "Rashguard Raiz", cost: 180, effect: { technique: 3, honor: 1 }, desc: "Conforto e identidade no tatame." },
  { id: "kimono", name: "Kimono Respeito", cost: 220, effect: { honor: 3, focus: 2 }, desc: "Presença limpa e postura séria." },
  { id: "corda", name: "Corda Profissa", cost: 150, effect: { cardio: 2, strength: 1 }, desc: "Ritmo, base e pulmão." },
  { id: "protetor", name: "Protetor Campeão", cost: 190, effect: { maxHp: 12 }, desc: "Aguenta mais porrada sem desmontar." }
];

const talentsMaster = {
  talent_tempo: { id: "talent_tempo", name: "Tempo Perfeito", desc: "+10% no dano de contra-ataque e +2 foco.", unlocked: false },
  talent_guardiao: { id: "talent_guardiao", name: "Guarda Fechada", desc: "+10% de defesa ao usar Proteger e +2 técnica.", unlocked: false },
  talent_ferro: { id: "talent_ferro", name: "Queixo de Ferro", desc: "+14 de HP máximo e +2 força.", unlocked: false },
  talent_sangue_frio: { id: "talent_sangue_frio", name: "Sangue Frio", desc: "Respirar cura mais e dá +2 foco.", unlocked: false },
  talent_cascadura: { id: "talent_cascadura", name: "Casca Dura", desc: "+18 de HP máximo e mais resistência mental.", unlocked: false },
  talent_lobo: { id: "talent_lobo", name: "Lobo de Final", desc: "Finalização ganha mais precisão e +2 técnica.", unlocked: false },
  talent_campeao: { id: "talent_campeao", name: "Pulso de Campeão", desc: "Golpes simples batem mais forte e +2 força.", unlocked: false }
};

const achievementsMaster = [
  { id: "first_win", name: "Primeiro sangue frio", desc: "Vença sua primeira missão." },
  { id: "all_ch1", name: "Base montada", desc: "Conclua o Capítulo 1." },
  { id: "shopper", name: "Equipado", desc: "Compre 3 itens na loja." },
  { id: "disciplina", name: "Constância", desc: "Treine 10 vezes." },
  { id: "midgame", name: "Nome no mapa", desc: "Conclua o Capítulo 4." },
  { id: "all_items", name: "Arsenal completo", desc: "Compre todos os itens da loja." },
  { id: "lvl15", name: "Veterano", desc: "Alcance o nível 15." },
  { id: "finale", name: "Lenda do Tatame", desc: "Zere a campanha completa." }
];

function initialState() {
  return {
    playerName: "Cria do Tatame",
    level: 1,
    xp: 0,
    nextLevelXp: 100,
    coins: 100,
    energy: 6,
    maxEnergy: 6,
    baseStats: { strength: 8, technique: 8, cardio: 8, focus: 8, honor: 8 },
    bonusStats: { strength: 0, technique: 0, cardio: 0, focus: 0, honor: 0, maxHp: 0 },
    inventory: [],
    completedMissions: [],
    trainingCount: 0,
    log: ["Você entrou no dojo. O caminho começa agora."],
    daily: generateDaily(),
    completedDailyOnTick: [],
    talents: JSON.parse(JSON.stringify(talentsMaster)),
    achievements: [],
    battleState: null,
    history: ["Um novo lutador começou sua jornada."],
    endingUnlocked: false
  };
}

function generateDaily() {
  return [
    { id: "daily_train", label: "Treinar 2 vezes", progress: 0, goal: 2, reward: { xp: 20, coins: 30 }, done: false },
    { id: "daily_shop", label: "Comprar 1 item", progress: 0, goal: 1, reward: { xp: 15, coins: 0 }, done: false },
    { id: "daily_fight", label: "Vencer 1 missão", progress: 0, goal: 1, reward: { xp: 25, coins: 35 }, done: false }
  ];
}

let state = loadState();
const el = (id) => document.getElementById(id);

function loadState() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : initialState();
  } catch {
    return initialState();
  }
}

function saveState(showMessage = true) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  if (showMessage) toast("Jogo salvo com sucesso.");
}

function resetGame() {
  openModal("Novo jogo", `
    <p>Começar do zero? Sem mimimi: seu progresso atual será apagado.</p>
    <input id="nameInput" class="input-name" maxlength="24" placeholder="Digite o nome do lutador" />
    <div class="actions">
      <button id="confirmNewGame" class="danger">Começar nova jornada</button>
    </div>
  `);
  const input = el("nameInput");
  input.value = "Cria do Tatame";
  el("confirmNewGame").onclick = () => {
    state = initialState();
    state.playerName = input.value.trim() || "Cria do Tatame";
    state.log.unshift(`Novo jogo iniciado com ${state.playerName}.`);
    state.history.unshift(`${state.playerName} decidiu começar tudo de novo.`);
    saveState(false);
    closeModal();
    render();
  };
}

function toast(text) {
  state.log.unshift(text);
  renderLogOnly();
}

function getStats() {
  const totals = {};
  Object.keys(state.baseStats).forEach((k) => {
    totals[k] = state.baseStats[k] + (state.bonusStats[k] || 0);
  });
  return totals;
}

function maxHp() {
  const s = getStats();
  let hp = 80 + s.strength * 2 + s.cardio * 2 + (state.bonusStats.maxHp || 0);
  if (state.talents.talent_ferro?.unlocked) hp += 14;
  return hp;
}

function gainXP(amount) {
  state.xp += amount;
  while (state.xp >= state.nextLevelXp) {
    state.xp -= state.nextLevelXp;
    state.level += 1;
    state.nextLevelXp = Math.round(state.nextLevelXp * 1.15);
    state.baseStats.strength += 1;
    state.baseStats.technique += 1;
    state.baseStats.cardio += 1;
    state.baseStats.focus += 1;
    state.baseStats.honor += 1;
    state.coins += 25;
    state.history.unshift(`${state.playerName} alcançou o nível ${state.level}.`);
    state.log.unshift(`Nível ${state.level}! Todos os atributos base subiram.`);
  }
}

function spendEnergy(cost) {
  if (state.energy < cost) {
    toast("Energia insuficiente. Vai descansar, campeão.");
    return false;
  }
  state.energy -= cost;
  return true;
}

function completeDaily(id) {
  const daily = state.daily.find((d) => d.id === id);
  if (!daily || daily.done) return;
  daily.progress += 1;
  if (daily.progress >= daily.goal) {
    daily.done = true;
    gainXP(daily.reward.xp);
    state.coins += daily.reward.coins;
    state.log.unshift(`Tarefa diária concluída: ${daily.label}`);
  }
}

function applyAchievementCheck() {
  if (state.completedMissions.length >= 1) unlockAchievement("first_win");
  if ([1,2,3].every((m) => state.completedMissions.includes(m))) unlockAchievement("all_ch1");
  if (state.inventory.length >= 3) unlockAchievement("shopper");
  if (state.trainingCount >= 10) unlockAchievement("disciplina");
  if ([10,11,12].every((m) => state.completedMissions.includes(m))) unlockAchievement("midgame");
  if (state.inventory.length === shopItems.length) unlockAchievement("all_items");
  if (state.level >= 15) unlockAchievement("lvl15");
  if (state.completedMissions.includes(24)) unlockAchievement("finale");
}

function unlockAchievement(id) {
  if (state.achievements.includes(id)) return;
  state.achievements.push(id);
  const ach = achievementsMaster.find((a) => a.id === id);
  if (ach) {
    state.log.unshift(`Conquista desbloqueada: ${ach.name}`);
    state.history.unshift(`Conquista obtida: ${ach.name}.`);
    state.coins += 20;
  }
}

function unlockTalent(id) {
  const talent = state.talents[id];
  if (!talent || talent.unlocked) return;
  talent.unlocked = true;
  if (id === "talent_tempo") state.bonusStats.focus += 2;
  if (id === "talent_guardiao") state.bonusStats.technique += 2;
  if (id === "talent_ferro") state.bonusStats.strength += 2;
  if (id === "talent_sangue_frio") state.bonusStats.focus += 2;
  if (id === "talent_cascadura") state.bonusStats.maxHp += 18;
  if (id === "talent_lobo") state.bonusStats.technique += 2;
  if (id === "talent_campeao") state.bonusStats.strength += 2;
  state.log.unshift(`Talento desbloqueado: ${talent.name}`);
  state.history.unshift(`Novo talento: ${talent.name}.`);
}

function doTraining(trainingId) {
  const t = trainings.find((x) => x.id === trainingId);
  if (!t) return;

  if (t.id === "descanso") {
    state.energy = state.maxEnergy;
    gainXP(8);
    state.log.unshift("Você descansou. Corpo recuperado e mente mais leve.");
    saveState(false);
    render();
    return;
  }

  if (!spendEnergy(t.energyCost)) return;
  Object.entries(t.effect).forEach(([key, value]) => {
    if (key === "xp") gainXP(value);
    else if (key in state.baseStats) state.baseStats[key] += value;
  });

  state.trainingCount += 1;
  completeDaily("daily_train");
  state.log.unshift(`${t.name}: ${t.flavor}`);
  state.history.unshift(`Treino feito: ${t.name}.`);
  applyAchievementCheck();
  saveState(false);
  render();
}

function buyItem(itemId) {
  const item = shopItems.find((x) => x.id === itemId);
  if (!item) return;
  if (state.inventory.includes(itemId)) return toast("Você já tem esse item.");
  if (state.coins < item.cost) return toast("Moeda curta. Vai pra missão ou treina mais.");
  state.coins -= item.cost;
  state.inventory.push(itemId);
  Object.entries(item.effect).forEach(([key, value]) => {
    state.bonusStats[key] = (state.bonusStats[key] || 0) + value;
  });
  completeDaily("daily_shop");
  state.log.unshift(`Compra feita: ${item.name}.`);
  state.history.unshift(`${state.playerName} comprou ${item.name}.`);
  applyAchievementCheck();
  saveState(false);
  render();
}

function availableMissions() {
  return missionsMaster.filter((mission) => {
    if (mission.id === 1) return true;
    return state.completedMissions.includes(mission.id - 1);
  });
}

function missionCompleted(id) {
  return state.completedMissions.includes(id);
}

function missionUnlocked(id) {
  return availableMissions().some((m) => m.id === id);
}

function chooseMission(id) {
  const mission = missionsMaster.find((m) => m.id === id);
  if (!mission || !missionUnlocked(id)) return;
  renderBattleArea(mission);
}

function startMission(id) {
  const mission = missionsMaster.find((m) => m.id === id);
  if (!mission || missionCompleted(id)) return;
  if (!spendEnergy(mission.energyCost)) return;

  state.battleState = {
    missionId: id,
    playerHp: maxHp(),
    enemyHp: mission.opponent.hp,
    turn: 1,
    defending: false,
    playerBuff: null,
    enemyBuff: null,
    log: [`${state.playerName} encarou ${mission.opponent.name}. A luta começou.`],
    finished: false
  };
  saveState(false);
  renderBattleArea(mission);
  renderHeader();
}

function randomBetween(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function battlePlayerAction(action) {
  const battle = state.battleState;
  if (!battle || battle.finished) return;
  const mission = missionsMaster.find((m) => m.id === battle.missionId);
  const stats = getStats();
  const enemy = mission.opponent;

  let message = "";
  let damage = 0;

  if (action === "jab") {
    damage = Math.max(4, Math.round(stats.technique * 0.9 + stats.focus * 0.4 + randomBetween(2,7) - enemy.technique * 0.25));
    if (state.talents.talent_campeao?.unlocked) damage = Math.round(damage * 1.12);
    message = `${state.playerName} encaixou jab + direto e causou ${damage}.`;
  }
  if (action === "queda") {
    damage = Math.max(5, Math.round(stats.strength * 0.8 + stats.technique * 0.6 + randomBetween(1,8) - enemy.focus * 0.2));
    message = `${state.playerName} entrou na queda e somou ${damage}.`;
  }
  if (action === "finalizacao") {
    const chance = stats.technique + stats.focus + randomBetween(1,20);
    if (state.talents.talent_lobo?.unlocked) chance += 6;
    if (chance > enemy.technique + enemy.focus + 12) {
      damage = Math.max(10, Math.round(stats.technique * 1.25 + randomBetween(6,12)));
      message = `${state.playerName} quase pegou a finalização e aplicou ${damage}.`;
    } else {
      damage = Math.max(2, Math.round(stats.technique * 0.35 + randomBetween(1,4)));
      message = `${state.playerName} buscou a finalização, mas arrancou só ${damage}.`;
    }
  }
  if (action === "proteger") {
    battle.defending = true;
    message = `${state.playerName} fechou a guarda e travou a defesa.`;
  }
  if (action === "respirar") {
    let heal = Math.min(18, Math.round(stats.cardio * 0.9 + stats.focus * 0.4));
    if (state.talents.talent_sangue_frio?.unlocked) heal = Math.round(heal * 1.35);
    battle.playerHp = Math.min(maxHp(), battle.playerHp + heal);
    message = `${state.playerName} respirou, recompôs a base e recuperou ${heal} de HP.`;
  }

  if (damage > 0) battle.enemyHp = Math.max(0, battle.enemyHp - damage);
  battle.log.unshift(message);

  if (battle.enemyHp <= 0) return finishBattle(true);

  enemyTurn();
  battle.turn += 1;
  renderBattleArea(mission);
  saveState(false);
}

function enemyTurn() {
  const battle = state.battleState;
  const mission = missionsMaster.find((m) => m.id === battle.missionId);
  const enemy = mission.opponent;
  const stats = getStats();

  const moves = ["combo", "clinch", "explosao", "pressao"];
  const move = moves[randomBetween(0, moves.length - 1)];
  let damage = 0;
  let msg = "";

  if (move === "combo") {
    damage = Math.max(4, Math.round(enemy.technique * 0.8 + enemy.focus * 0.3 + randomBetween(2,7) - stats.technique * 0.2));
    msg = `${enemy.name} respondeu com combinação e causou ${damage}.`;
  }
  if (move === "clinch") {
    damage = Math.max(5, Math.round(enemy.strength * 0.75 + enemy.technique * 0.4 + randomBetween(1,6) - stats.focus * 0.2));
    msg = `${enemy.name} grudou no clinch e desgastou ${damage}.`;
  }
  if (move === "explosao") {
    damage = Math.max(6, Math.round(enemy.strength * 0.9 + enemy.cardio * 0.35 + randomBetween(2,9) - stats.cardio * 0.2));
    msg = `${enemy.name} explodiu e acertou ${damage}.`;
  }
  if (move === "pressao") {
    damage = Math.max(4, Math.round(enemy.cardio * 0.7 + enemy.technique * 0.4 + randomBetween(1,7) - stats.honor * 0.1));
    msg = `${enemy.name} manteve pressão constante e tirou ${damage}.`;
  }

  if (battle.defending) {
    let reduce = 0.35;
    if (state.talents.talent_guardiao?.unlocked) reduce = 0.45;
    if (state.talents.talent_tempo?.unlocked) {
      const counter = Math.max(2, Math.round(stats.focus * 0.35 + randomBetween(1,4)));
      battle.enemyHp = Math.max(0, battle.enemyHp - counter);
      battle.log.unshift(`${state.playerName} contra-atacou na saída e devolveu ${counter}.`);
    }
    damage = Math.round(damage * (1 - reduce));
    msg += ` A guarda reduziu o dano.`;
    battle.defending = false;
  }

  battle.playerHp = Math.max(0, battle.playerHp - damage);
  battle.log.unshift(msg);

  if (battle.enemyHp <= 0) return finishBattle(true);
  if (battle.playerHp <= 0) return finishBattle(false);
}

function finishBattle(victory) {
  const battle = state.battleState;
  if (!battle) return;
  const mission = missionsMaster.find((m) => m.id === battle.missionId);
  battle.finished = true;

  if (victory) {
    battle.log.unshift(`Vitória! ${state.playerName} venceu ${mission.opponent.name}.`);
    if (!state.completedMissions.includes(mission.id)) {
      state.completedMissions.push(mission.id);
      state.coins += mission.rewardCoins;
      gainXP(mission.rewardXp);
      mission.unlocks.forEach((id) => {
        if (id === "ending") state.endingUnlocked = true;
        else unlockTalent(id);
      });
      completeDaily("daily_fight");
      state.history.unshift(`Missão concluída: ${mission.name}.`);
    }
  } else {
    battle.log.unshift(`Derrota. ${state.playerName} caiu, mas volta melhor.`);
    gainXP(Math.round(mission.rewardXp * 0.25));
    state.history.unshift(`Derrota aprendida na missão ${mission.name}.`);
  }
  applyAchievementCheck();
  saveState(false);
  render();

  if (victory && state.endingUnlocked) {
    setTimeout(showEnding, 250);
  }
}

function showEnding() {
  const stats = getStats();
  let titulo = "Final da campanha";
  let texto1 = `<strong>${state.playerName}</strong> venceu o Imperador do Tatame e fechou a campanha principal.`;
  let texto2 = "Não foi no grito. Foi no treino acumulado, no respeito e na casca criada dia após dia.";

  if (stats.honor >= stats.strength && stats.honor >= stats.technique) {
    titulo = "Final Honra de Aço";
    texto1 = `<strong>${state.playerName}</strong> virou referência de postura, respeito e liderança no tatame.`;
    texto2 = "Seu nome pesa não só porque venceu, mas porque ensina pelo exemplo.";
  } else if (stats.technique >= stats.strength) {
    titulo = "Final Mente Fria";
    texto1 = `<strong>${state.playerName}</strong> venceu na leitura, no tempo e na técnica refinada.`;
    texto2 = "Você não atropelou a luta; desmontou ela peça por peça.";
  } else {
    titulo = "Final Punho de Pedra";
    texto1 = `<strong>${state.playerName}</strong> fechou a jornada na potência, pressão e coragem.`;
    texto2 = "Quando precisou andar pra frente, você andou. Quando precisou aguentar, você aguentou.";
  }

  openModal(titulo, `
    <div class="log-entry">${texto1}</div>
    <div class="log-entry">${texto2}</div>
    <div class="log-entry">Modo livre destravado: termine tudo, compre tudo e lapide sua build.</div>
    <div class="actions">
      <button id="closeEnding" class="secondary">Seguir no modo livre</button>
    </div>
  `);
  el("closeEnding").onclick = closeModal;
}

function renderHeader() {
  el("playerName").textContent = state.playerName;
  el("levelText").textContent = state.level;
  el("xpText").textContent = `${state.xp} / ${state.nextLevelXp}`;
  el("coinsText").textContent = state.coins;
  el("energyText").textContent = `${state.energy} / ${state.maxEnergy}`;

  const lastMission = missionsMaster.find((m) => !missionCompleted(m.id) && missionUnlocked(m.id));
  el("storyText").textContent = lastMission
    ? `Próximo passo: ${lastMission.name}. ${lastMission.story}`
    : "Você zerou a campanha principal. Agora é lapidar o legado.";
}

function renderStats() {
  const stats = getStats();
  const maxVal = Math.max(...Object.values(stats), 100);
  el("statsGrid").innerHTML = `
    ${Object.entries(stats).map(([key, val]) => `
      <div class="stat-item">
        <div class="stat-top">
          <strong>${statLabel(key)}</strong>
          <span>${val}</span>
        </div>
        <div class="bar"><div class="bar-fill" style="width:${Math.min(100, (val / maxVal) * 100)}%"></div></div>
      </div>
    `).join("")}
    <div class="stat-item">
      <div class="stat-top"><strong>HP Máximo</strong><span>${maxHp()}</span></div>
      <div class="bar"><div class="bar-fill" style="width:${Math.min(100, maxHp())}%"></div></div>
    </div>
  `;
}

function statLabel(key) {
  return {
    strength: "Força",
    technique: "Técnica",
    cardio: "Cardio",
    focus: "Foco",
    honor: "Honra"
  }[key] || key;
}

function renderCurrentMission() {
  const nextMission = missionsMaster.find((m) => !missionCompleted(m.id) && missionUnlocked(m.id));
  const stats = getStats();
  if (!nextMission) {
    el("currentMissionCard").innerHTML = `<p>Campanha principal concluída. Agora é melhorar build, comprar tudo e bater recordes.</p>`;
    return;
  }
  const power = Object.values(stats).reduce((a, b) => a + b, 0);
  const diff = nextMission.recommended - Math.round(power / 5);
  const tone = diff <= 0 ? "badge" : diff < 8 ? "badge warn" : "badge danger";
  const diffText = diff <= 0 ? "Pronto para encarar" : diff < 8 ? "Pode ir, mas treine mais um pouco" : "Melhor fortalecer antes";
  el("currentMissionCard").innerHTML = `
    <div class="mission-card">
      <h4>${nextMission.name}</h4>
      <p>${nextMission.story}</p>
      <div class="meta">
        <span class="badge">Energia ${nextMission.energyCost}</span>
        <span class="badge">Recomendado ${nextMission.recommended}</span>
        <span class="${tone}">${diffText}</span>
      </div>
      <button onclick="switchTab('campanha'); chooseMission(${nextMission.id});">Ir para a missão</button>
    </div>
  `;
}

function renderDaily() {
  el("dailyList").innerHTML = state.daily.map((d) => `
    <div class="daily-item">
      <div class="mission-header">
        <strong>${d.label}</strong>
        <span class="badge ${d.done ? '' : 'warn'}">${d.progress}/${d.goal}</span>
      </div>
      <p class="small">Recompensa: +${d.reward.xp} XP ${d.reward.coins ? `e ${d.reward.coins} moedas` : ""}</p>
    </div>
  `).join("");
}

function renderAchievements() {
  if (!state.achievements.length) {
    el("achievementsList").innerHTML = `<p class="empty">Ainda sem conquistas. Bora trabalhar.</p>`;
    return;
  }
  el("achievementsList").innerHTML = state.achievements.map((id) => {
    const ach = achievementsMaster.find((a) => a.id === id);
    return `<div class="ach-item"><strong>${ach.name}</strong><p class="small">${ach.desc}</p></div>`;
  }).join("");
}

function renderChapters() {
  el("chapterProgress").innerHTML = chapters.map((ch) => {
    const done = ch.missionIds.every((id) => missionCompleted(id));
    const count = ch.missionIds.filter((id) => missionCompleted(id)).length;
    return `
      <div class="chapter-item ${done ? 'done' : ''}">
        <strong>Capítulo ${ch.id}: ${ch.name}</strong>
        <p class="small">${ch.description}</p>
        <div class="meta">
          <span class="badge">${count}/${ch.missionIds.length} missões</span>
          ${done ? '<span class="badge">Concluído</span>' : ''}
        </div>
      </div>
    `;
  }).join("");
}

function renderMissionList() {
  el("missionList").innerHTML = missionsMaster.map((mission) => {
    const done = missionCompleted(mission.id);
    const unlocked = missionUnlocked(mission.id);
    return `
      <div class="mission-card ${!unlocked ? 'locked' : ''}">
        <div class="mission-header">
          <h4>${mission.id}. ${mission.name}</h4>
          ${done ? '<span class="badge">Concluída</span>' : `<span class="badge warn">Cap. ${mission.chapter}</span>`}
        </div>
        <p>${mission.story}</p>
        <div class="meta">
          <span class="badge">${mission.opponent.name}</span>
          <span class="badge">Recomendado ${mission.recommended}</span>
          <span class="badge">Energia ${mission.energyCost}</span>
        </div>
        <div class="actions">
          <button ${!unlocked ? 'disabled' : ''} onclick="chooseMission(${mission.id})">Ver</button>
          <button class="secondary" ${!unlocked || done ? 'disabled' : ''} onclick="startMission(${mission.id})">Lutar</button>
        </div>
      </div>
    `;
  }).join("");
}

function renderBattleArea(mission = null) {
  const target = el("battleArea");
  const m = mission || missionsMaster.find((x) => x.id === state.battleState?.missionId);
  if (!m) {
    target.innerHTML = `<p>Escolha uma missão para ver o combate.</p>`;
    return;
  }

  const battle = state.battleState && state.battleState.missionId === m.id ? state.battleState : null;
  const stats = getStats();
  target.innerHTML = `
    <div class="fighter-row">
      <div class="fighter">
        <h4>${state.playerName}</h4>
        <p class="small">Estilo: Cria completo</p>
        <div class="bar"><div class="bar-fill" style="width:${battle ? (battle.playerHp / maxHp()) * 100 : 100}%"></div></div>
        <p><strong>HP:</strong> ${battle ? battle.playerHp : maxHp()} / ${maxHp()}</p>
        <p class="small">Força ${stats.strength} · Técnica ${stats.technique} · Cardio ${stats.cardio} · Foco ${stats.focus}</p>
      </div>
      <div class="vs">VS</div>
      <div class="fighter">
        <h4>${m.opponent.name}</h4>
        <p class="small">${m.opponent.style}</p>
        <div class="bar"><div class="bar-fill" style="width:${battle ? (battle.enemyHp / m.opponent.hp) * 100 : 100}%"></div></div>
        <p><strong>HP:</strong> ${battle ? battle.enemyHp : m.opponent.hp} / ${m.opponent.hp}</p>
        <p class="small">Força ${m.opponent.strength} · Técnica ${m.opponent.technique} · Cardio ${m.opponent.cardio} · Foco ${m.opponent.focus}</p>
      </div>
    </div>
    <div class="meta">
      <span class="badge">Missão ${m.id}</span>
      <span class="badge">Recompensa ${m.rewardCoins} moedas</span>
      <span class="badge">${m.rewardXp} XP</span>
    </div>
    <p>${m.story}</p>
    ${!battle ? `
      <div class="actions">
        <button class="secondary" ${missionCompleted(m.id) ? 'disabled' : ''} onclick="startMission(${m.id})">${missionCompleted(m.id) ? 'Já concluída' : 'Começar combate'}</button>
      </div>
    ` : `
      <div class="actions">
        <button onclick="battlePlayerAction('jab')" ${battle.finished ? 'disabled' : ''}>Jab + Direto</button>
        <button onclick="battlePlayerAction('queda')" ${battle.finished ? 'disabled' : ''}>Entrada de Queda</button>
        <button onclick="battlePlayerAction('finalizacao')" ${battle.finished ? 'disabled' : ''}>Finalização</button>
        <button class="warn" onclick="battlePlayerAction('proteger')" ${battle.finished ? 'disabled' : ''}>Proteger</button>
        <button class="secondary" onclick="battlePlayerAction('respirar')" ${battle.finished ? 'disabled' : ''}>Respirar</button>
      </div>
      <div class="battle-log">
        ${battle.log.map((entry) => `<div class="battle-entry ${entry.includes('Vitória') ? 'good' : entry.includes('Derrota') ? 'bad' : ''}">${entry}</div>`).join('')}
      </div>
    `}
  `;
}

function renderTrainings() {
  el("trainingActions").innerHTML = trainings.map((t) => `
    <div class="training-card">
      <h4>${t.name}</h4>
      <p class="small">${t.flavor}</p>
      <p class="small">${t.id === 'descanso' ? 'Recupera toda a energia.' : `Custa ${t.energyCost} energia.`}</p>
      <button class="${t.id === 'descanso' ? 'secondary' : ''}" onclick="doTraining('${t.id}')">Executar</button>
    </div>
  `).join("");
}

function renderShop() {
  el("shopList").innerHTML = shopItems.map((item) => {
    const owned = state.inventory.includes(item.id);
    return `
      <div class="shop-item">
        <div class="shop-header">
          <h4>${item.name}</h4>
          <span class="badge">${item.cost} moedas</span>
        </div>
        <p class="small">${item.desc}</p>
        <p class="small">${Object.entries(item.effect).map(([k, v]) => `${k === 'maxHp' ? 'HP Máx' : statLabel(k)} +${v}`).join(' · ')}</p>
        <button ${owned ? 'disabled' : ''} onclick="buyItem('${item.id}')">${owned ? 'Comprado' : 'Comprar'}</button>
      </div>
    `;
  }).join("");
}

function renderTalents() {
  el("talentsList").innerHTML = Object.values(state.talents).map((talent) => `
    <div class="talent-card">
      <div class="talent-header">
        <h4>${talent.name}</h4>
        <span class="badge ${talent.unlocked ? '' : 'warn'}">${talent.unlocked ? 'Desbloqueado' : 'Bloqueado'}</span>
      </div>
      <p class="small">${talent.desc}</p>
    </div>
  `).join("");
}

function renderHistory() {
  el("historyList").innerHTML = state.history.slice(0, 24).map((entry) => `<div class="log-entry">${entry}</div>`).join("");
}

function renderLogOnly() {
  el("trainingLog").innerHTML = state.log.slice(0, 20).map((entry) => `<div class="log-entry">${entry}</div>`).join("");
}

function renderTrainingLog() {
  renderLogOnly();
}

function openModal(title, html) {
  el("modalTitle").textContent = title;
  el("modalBody").innerHTML = html;
  el("modal").classList.remove("hidden");
}

function closeModal() {
  el("modal").classList.add("hidden");
}

function switchTab(id) {
  document.querySelectorAll(".tab").forEach((tab) => tab.classList.toggle("active", tab.dataset.tab === id));
  document.querySelectorAll(".tab-panel").forEach((panel) => panel.classList.toggle("active", panel.id === id));
}

function render() {
  renderHeader();
  renderStats();
  renderCurrentMission();
  renderDaily();
  renderAchievements();
  renderChapters();
  renderMissionList();
  renderBattleArea();
  renderTrainings();
  renderTrainingLog();
  renderShop();
  renderTalents();
  renderHistory();
}

window.switchTab = switchTab;
window.chooseMission = chooseMission;
window.startMission = startMission;
window.doTraining = doTraining;
window.buyItem = buyItem;
window.battlePlayerAction = battlePlayerAction;

function bindEvents() {
  document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => switchTab(tab.dataset.tab));
  });
  el("saveBtn").addEventListener("click", () => saveState(true));
  el("newGameBtn").addEventListener("click", resetGame);
  el("closeModalBtn").addEventListener("click", closeModal);
  el("modal").addEventListener("click", (e) => {
    if (e.target.id === "modal") closeModal();
  });
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  });
}

bindEvents();
applyAchievementCheck();
render();
